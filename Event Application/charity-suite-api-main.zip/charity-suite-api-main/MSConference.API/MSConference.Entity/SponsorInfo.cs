﻿namespace MSConference.Entity
{
    public class SponsorInfo : Sponsor, IBaseEntity
    {
        public bool IsActive { get; set; } = true;
        public bool IsDeleted { get; set; } = false;
        public int CreatedBy { get; set; } = 0;
    }
}

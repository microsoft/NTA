﻿namespace MSConference.Entity
{
    public interface IBaseEntity
    {
        bool IsActive { get; set; }
        bool IsDeleted { get; set; }
        int CreatedBy { get; set; }
    }
}

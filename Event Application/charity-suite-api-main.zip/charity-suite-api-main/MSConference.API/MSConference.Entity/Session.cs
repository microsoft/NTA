﻿namespace MSConference.Entity
{
    public class Session
    {
        public int ID { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string SpeakerName { get; set; } = string.Empty;
        public DateTime SessionDate { get; set; }
        public string SessionTime { get; set; }= string.Empty;
        public int ConferenceID { get; set; }
    }
}

﻿namespace MSConference.Entity
{
    public class SessionInfo : Session, IBaseEntity
    {
        public bool IsActive { get; set; } = true;
        public bool IsDeleted { get; set; } = false;
        public int CreatedBy { get; set; } = 0;
        public string ConferenceName { get; set; } = string.Empty;
    }
}

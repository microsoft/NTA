﻿using MSConference.Entity;

namespace MSConference.Manager
{
    public interface ISessionManager
    {
        int Add(Session obj);

        int Edit(Session obj);

        SessionInfo Get(int id);

        List<SessionInfo> Get();

        bool Delete(int id);
    }
}

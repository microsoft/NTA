﻿using Microsoft.Extensions.Options;
using MSConference.Entity;
using MSConference.Manager.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace MSConference.Manager
{
    public class UserManager : IUserManager
    {
        #region "Private Fields"

        private readonly AppSettings _appSettings;
        private readonly string connectionString;

        #endregion

        #region "Constructor"
        public UserManager(IOptions<AppSettings> options)
        {
            connectionString = options.Value.DBConnection;
            _appSettings = options.Value;
        }
        #endregion        

        public async Task<User> Authenticate(string username, string password)
        {
            User _resutl;

            using (SqlDataReader dr = await SqlHelper.ExecuteReaderAsync(connectionString, CommandType.StoredProcedure, "UserGet"
                    , new SqlParameter("@username", username)
                    , new SqlParameter("@password", password)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = new User();

                        _resutl.ID = Convert.ToInt32(dr["ID"]);
                        _resutl.FirstName = Convert.ToString(dr["FirstName"]);
                        _resutl.LastName = Convert.ToString(dr["LastName"]);
                        _resutl.Email = Convert.ToString(dr["Email"]);
                        _resutl.Phone = Convert.ToString(dr["Phone"]);

                        return _resutl;
                    }
                }
            }

            return null;
        }
    }
}

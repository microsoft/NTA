﻿using Microsoft.Extensions.Options;
using MSConference.Entity;
using MSConference.Manager.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.Xml.Linq;
using System.Runtime.Remoting;

namespace MSConference.Manager
{
    public class ConferenceManager : IConferenceManager
    {
        #region "Private Fields"

        private readonly AppSettings _appSettings;
        private readonly string connectionString;

        #endregion

        #region "Constructor"
        public ConferenceManager(IOptions<AppSettings> options)
        {
            connectionString = options.Value.DBConnection;
            _appSettings = options.Value;
        }
        #endregion

        public int Add(Conference obj)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "ConferenceAdd"
                    , new SqlParameter("@Name", obj.Name)
                    , new SqlParameter("@Address", obj.Address)
                    , new SqlParameter("@StartDate", obj.StartDate)
                    , new SqlParameter("@EndDate", obj.EndDate)
                    , new SqlParameter("@Description", obj.Description)
                    , new SqlParameter("@CreatedBy", _appSettings.DefaultUserID)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return _resutl;
        }

        public int Edit(Conference obj)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "ConferenceEdit"
                    , new SqlParameter("@Name", obj.Name)
                    , new SqlParameter("@Address", obj.Address)
                    , new SqlParameter("@StartDate", obj.StartDate)
                    , new SqlParameter("@EndDate", obj.EndDate)
                    , new SqlParameter("@Description", obj.Description)
                    , new SqlParameter("@ModifiedBy", _appSettings.DefaultUserID)
                    , new SqlParameter("@ID", obj.ID)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return _resutl;
        }

        public ConferenceInfo Get(int id)
        {
            ConferenceInfo _resutl = new ConferenceInfo();

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "ConferenceGet"
                    , new SqlParameter("@ID", id)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl.ID = Convert.ToInt32(dr["ID"]);
                        _resutl.Name = Convert.ToString(dr["Name"]);
                        _resutl.Address = Convert.ToString(dr["Address"]);
                        _resutl.Description = Convert.ToString(dr["Description"]);
                        _resutl.StartDate = Convert.ToDateTime(dr["StartDate"]);
                        _resutl.EndDate = Convert.ToDateTime(dr["EndDate"]);
                        _resutl.IsActive = Convert.ToBoolean(dr["IsActive"]);
                        _resutl.IsDeleted = Convert.ToBoolean(dr["IsDeleted"]);
                        _resutl.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);
                        _resutl.Sessions = new List<SessionInfo>();
                    }

                    dr.NextResult();

                    while (dr.Read())
                    {
                        _resutl.Sessions.Add(new SessionInfo()
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            Name = Convert.ToString(dr["Name"]),
                            Description = Convert.ToString(dr["Description"]),
                            SessionDate = Convert.ToDateTime(dr["SessionDate"]),
                            SessionTime = Convert.ToString(dr["SessionTime"]),
                            SpeakerName = Convert.ToString(dr["SpeakerName"]),
                            IsActive = Convert.ToBoolean(dr["IsActive"]),
                            IsDeleted = Convert.ToBoolean(dr["IsDeleted"]),
                            CreatedBy = Convert.ToInt32(dr["CreatedBy"])
                        });
                    }
                }
            }

            return _resutl;
        }

        public List<ConferenceInfo> Get()
        {
            List<ConferenceInfo> _resutl = new List<ConferenceInfo>();

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "ConferenceList"))
            {
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        _resutl.Add(new ConferenceInfo()
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            Name = Convert.ToString(dr["Name"]),
                            Address = Convert.ToString(dr["Address"]),
                            Description = Convert.ToString(dr["Description"]),
                            StartDate = Convert.ToDateTime(dr["StartDate"]),
                            EndDate = Convert.ToDateTime(dr["EndDate"]),
                            IsActive = Convert.ToBoolean(dr["IsActive"]),
                            IsDeleted = Convert.ToBoolean(dr["IsDeleted"]),
                            CreatedBy = Convert.ToInt32(dr["CreatedBy"]),
                        });
                    }
                }
            }

            return _resutl;
        }

        public bool Delete(int id)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "ConferenceDelete"
                    , new SqlParameter("@ID", id)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return (_resutl > 0) ? true : false;
        }
    }
}
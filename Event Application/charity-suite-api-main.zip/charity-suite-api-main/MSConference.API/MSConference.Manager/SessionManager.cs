﻿using Microsoft.Extensions.Options;
using MSConference.Entity;
using MSConference.Manager.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MSConference.Manager
{
    public class SessionManager : ISessionManager
    {
        #region "Private Fields"

        private readonly AppSettings _appSettings;
        private readonly string connectionString;

        #endregion

        #region "Constructor"
        public SessionManager(IOptions<AppSettings> options)
        {
            connectionString = options.Value.DBConnection;
            _appSettings = options.Value;
        }
        #endregion        

        public int Add(Session obj)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SessionAdd"
                    , new SqlParameter("@Name", obj.Name)
                    , new SqlParameter("@Description", obj.Description)
                    , new SqlParameter("@SessionDate", obj.SessionDate)
                    , new SqlParameter("@SessionTime", obj.SessionTime)
                    , new SqlParameter("@SpeakerName", obj.SpeakerName)
                    , new SqlParameter("@CreatedBy", _appSettings.DefaultUserID)
                    , new SqlParameter("@ConferenceID", obj.ConferenceID)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return _resutl;
        }

        public int Edit(Session obj)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SessionEdit"
                    , new SqlParameter("@Name", obj.Name)
                    , new SqlParameter("@Description", obj.Description)
                    , new SqlParameter("@SessionDate", obj.SessionDate)
                    , new SqlParameter("@SessionTime", obj.SessionTime)
                    , new SqlParameter("@SpeakerName", obj.SpeakerName)
                    , new SqlParameter("@ModifiedBy", _appSettings.DefaultUserID)
                    , new SqlParameter("@ID", obj.ID)
                    , new SqlParameter("@ConferenceID", obj.ConferenceID)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return _resutl;
        }

        public SessionInfo Get(int id)
        {
            SessionInfo _resutl = new SessionInfo();

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SessionGet"
                    , new SqlParameter("@ID", id)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl.ID = Convert.ToInt32(dr["ID"]);
                        _resutl.Name = Convert.ToString(dr["Name"]);
                        _resutl.Description = Convert.ToString(dr["Description"]);
                        _resutl.SessionDate = Convert.ToDateTime(dr["SessionDate"]);
                        _resutl.SessionTime = Convert.ToString(dr["SessionTime"]);
                        _resutl.SpeakerName = Convert.ToString(dr["SpeakerName"]);
                        _resutl.IsActive = Convert.ToBoolean(dr["IsActive"]);
                        _resutl.IsDeleted = Convert.ToBoolean(dr["IsDeleted"]);
                        _resutl.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);
                        _resutl.ConferenceID = Convert.ToInt32(dr["ConferenceID"]);
                        _resutl.ConferenceName = Convert.ToString(dr["ConferenceName"]);
                    }
                }
            }

            return _resutl;
        }

        public List<SessionInfo> Get()
        {
            List<SessionInfo> _resutl = new List<SessionInfo>();

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SessionList"))
            {
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        _resutl.Add(new SessionInfo()
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            Name = Convert.ToString(dr["Name"]),
                            Description = Convert.ToString(dr["Description"]),
                            SessionDate = Convert.ToDateTime(dr["SessionDate"]),
                            SessionTime = Convert.ToString(dr["SessionTime"]),
                            SpeakerName = Convert.ToString(dr["SpeakerName"]),
                            IsActive = Convert.ToBoolean(dr["IsActive"]),
                            IsDeleted = Convert.ToBoolean(dr["IsDeleted"]),
                            CreatedBy = Convert.ToInt32(dr["CreatedBy"]),
                            ConferenceID = Convert.ToInt32(dr["ConferenceID"]),
                            ConferenceName = Convert.ToString(dr["ConferenceName"])
                        });
                    }
                }
            }

            return _resutl;
        }

        public bool Delete(int id)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SessionDelete"
                    , new SqlParameter("@ID", id)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return (_resutl > 0) ? true : false;
        }
    }
}

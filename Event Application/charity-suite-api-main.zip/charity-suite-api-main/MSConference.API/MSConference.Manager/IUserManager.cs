﻿using MSConference.Entity;

namespace MSConference.Manager
{
    public interface IUserManager
    {
        Task<User> Authenticate(string username, string password);
    }
}

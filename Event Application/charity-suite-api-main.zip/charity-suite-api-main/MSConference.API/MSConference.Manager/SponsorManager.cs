﻿using Microsoft.Extensions.Options;
using MSConference.Entity;
using MSConference.Manager.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MSConference.Manager
{
    public class SponsorManager : ISponsorManager
    {
        #region "Private Fields"

        private readonly AppSettings _appSettings;
        private readonly string connectionString;

        #endregion

        #region "Constructor"
        public SponsorManager(IOptions<AppSettings> options)
        {
            connectionString = options.Value.DBConnection;
            _appSettings = options.Value;
        }
        #endregion

        public int Add(Sponsor obj)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SponsorAdd"
                    , new SqlParameter("@Name", obj.Name)
                    , new SqlParameter("@Description", obj.Description)
                    , new SqlParameter("@LogoURL", obj.LogoURL)
                    , new SqlParameter("@CreatedBy", _appSettings.DefaultUserID)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return _resutl;
        }

        public int Edit(Sponsor obj)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SponsorEdit"
                    , new SqlParameter("@Name", obj.Name)
                    , new SqlParameter("@Description", obj.Description)
                    , new SqlParameter("@LogoURL", obj.LogoURL)
                    , new SqlParameter("@ModifiedBy", _appSettings.DefaultUserID)
                    , new SqlParameter("@ID", obj.ID)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return _resutl;
        }

        public SponsorInfo Get(int id)
        {
            SponsorInfo _resutl = new SponsorInfo();

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SponsorGet"
                    , new SqlParameter("@ID", id)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl.ID = Convert.ToInt32(dr["ID"]);
                        _resutl.Name = Convert.ToString(dr["Name"]);
                        _resutl.Description = Convert.ToString(dr["Description"]);
                        _resutl.LogoURL = Convert.ToString(dr["LogoURL"]);
                        _resutl.IsActive = Convert.ToBoolean(dr["IsActive"]);
                        _resutl.IsDeleted = Convert.ToBoolean(dr["IsDeleted"]);
                        _resutl.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);
                    }
                }
            }

            return _resutl;
        }

        public List<SponsorInfo> Get()
        {
            List<SponsorInfo> _resutl = new List<SponsorInfo>();

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SponsorList"))
            {
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        _resutl.Add(new SponsorInfo()
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            Name = Convert.ToString(dr["Name"]),
                            Description = Convert.ToString(dr["Description"]),
                            LogoURL = Convert.ToString(dr["LogoURL"]),
                            IsActive = Convert.ToBoolean(dr["IsActive"]),
                            IsDeleted = Convert.ToBoolean(dr["IsDeleted"]),
                            CreatedBy = Convert.ToInt32(dr["CreatedBy"])
                        });
                    }
                }
            }

            return _resutl;
        }

        public bool Delete(int id)
        {
            int _resutl = 0;

            using (SqlDataReader dr = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, "SponsorDelete"
                    , new SqlParameter("@ID", id)
                    ))
            {
                if (dr != null && dr.HasRows)
                {
                    if (dr.Read())
                    {
                        _resutl = Convert.ToInt32(dr["ID"]);
                    }
                }
            }

            return (_resutl > 0) ? true : false;
        }
    }
}

﻿using MSConference.Entity;

namespace MSConference.Manager
{
    public interface IConferenceManager
    {
        int Add(Conference obj);

        int Edit(Conference obj);

        ConferenceInfo Get(int id);

        List<ConferenceInfo> Get();

        bool Delete(int id);
    }
}

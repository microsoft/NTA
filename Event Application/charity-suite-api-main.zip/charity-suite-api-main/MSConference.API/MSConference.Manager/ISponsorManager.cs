﻿using MSConference.Entity;

namespace MSConference.Manager
{
    public interface ISponsorManager
    {
        int Add(Sponsor obj);

        int Edit(Sponsor obj);

        SponsorInfo Get(int id);

        List<SponsorInfo> Get();

        bool Delete(int id);
    }
}

﻿namespace MSConference.Manager
{
    public interface IManager<T>
    {
        int Add(T obj);

        int Edit(T obj);

        T Get(int id);

        List<T> Get();

        bool Delete(int id);
    }
}

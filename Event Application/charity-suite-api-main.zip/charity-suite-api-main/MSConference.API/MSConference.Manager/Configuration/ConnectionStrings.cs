﻿using System.Diagnostics.CodeAnalysis;

namespace MSConference.Manager.Configuration
{
    [ExcludeFromCodeCoverage]
    public class ConnectionStrings
    {
        public string DbConnection { get; set; } = string.Empty;    
    }
}

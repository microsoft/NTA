﻿CREATE TABLE [dbo].[Users] (
    [ID]            INT            IDENTITY (1, 1) NOT NULL,
    [LogInName]     NVARCHAR (50)  NOT NULL,
    [LogInPassword] NVARCHAR (500) NOT NULL,
    [FirstName]     NVARCHAR (200) NOT NULL,
    [LastName]      NVARCHAR (200) NULL,
    [Email]         NVARCHAR (200) NULL,
    [Phone]         NVARCHAR (30)  NULL,
    [Address1]      NVARCHAR (200) NULL,
    [City]          NVARCHAR (200) NULL,
    [StateName]     NVARCHAR (200) NULL,
    [Zip]           NVARCHAR (200) NULL,
    [CountryName]   NVARCHAR (200) NULL,
    [IsActive]      BIT            CONSTRAINT [DF_Users_IsActive] DEFAULT ((1)) NOT NULL,
    [IsDeleted]     BIT            CONSTRAINT [DF_Users_IsDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedOn]     DATETIME       CONSTRAINT [DF_Users_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ModifiedOn]    DATETIME       NULL,
    CONSTRAINT [PK_Users_ID] PRIMARY KEY CLUSTERED ([ID] ASC)
);


﻿CREATE TABLE [dbo].[MyAgenda] (
    [ConferenceID] INT NOT NULL,
    [SessionID]    INT NOT NULL,
    CONSTRAINT [PK_MyAgenda_ConferenceID_SessionID] PRIMARY KEY CLUSTERED ([ConferenceID] ASC, [SessionID] ASC),
    CONSTRAINT [FK_MyAgenda_ConferenceID_Conference_ID] FOREIGN KEY ([ConferenceID]) REFERENCES [dbo].[Conference] ([ID]),
    CONSTRAINT [FK_MyAgenda_SessionID_Session_ID] FOREIGN KEY ([SessionID]) REFERENCES [dbo].[Session] ([ID])
);


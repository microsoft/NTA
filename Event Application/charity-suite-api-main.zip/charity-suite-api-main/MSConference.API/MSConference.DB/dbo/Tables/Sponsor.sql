﻿CREATE TABLE [dbo].[Sponsor] (
    [ID]          INT             IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (500)  NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    [LogoURL]     NVARCHAR (1000) NULL,
    [IsActive]    BIT             CONSTRAINT [DF_Sponsor_IsActive] DEFAULT ((1)) NOT NULL,
    [IsDeleted]   BIT             CONSTRAINT [DF_Sponsor_IsDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]   INT             NULL,
    [CreatedOn]   DATETIME        CONSTRAINT [DF_Sponsor_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ModifiedOn]  DATETIME        NULL,
    [ModifiedBy]  INT             NULL,
    CONSTRAINT [PK_Sponsor_ID] PRIMARY KEY CLUSTERED ([ID] ASC),
    CONSTRAINT [FK_Sponsor_CreatedBy_Users_ID] FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[Users] ([ID]),
    CONSTRAINT [FK_Sponsor_ModifiedBy_Users_ID] FOREIGN KEY ([ModifiedBy]) REFERENCES [dbo].[Users] ([ID])
);


﻿CREATE TABLE [dbo].[Session] (
    [ID]          INT             IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (500)  NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    [SessionDate] DATE            NULL,
    [SessionTime] TIME (7)        NULL,
    [SpeakerName] NVARCHAR (1000) NULL,
    [IsActive]    BIT             CONSTRAINT [DF_Session_IsActive] DEFAULT ((1)) NOT NULL,
    [IsDeleted]   BIT             CONSTRAINT [DF_Session_IsDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]   INT             NULL,
    [CreatedOn]   DATETIME        CONSTRAINT [DF_Session_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ModifiedOn]  DATETIME        NULL,
    [ModifiedBy]  INT             NULL,
    CONSTRAINT [PK_Session_ID] PRIMARY KEY CLUSTERED ([ID] ASC),
    CONSTRAINT [FK_Session_CreatedBy_Users_ID] FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[Users] ([ID]),
    CONSTRAINT [FK_Session_ModifiedBy_Users_ID] FOREIGN KEY ([ModifiedBy]) REFERENCES [dbo].[Users] ([ID])
);


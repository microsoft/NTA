﻿CREATE TABLE [dbo].[Conference] (
    [ID]          INT             IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (500)  NOT NULL,
    [Address]     NVARCHAR (1000) NOT NULL,
    [StartDate]   DATETIME        NOT NULL,
    [EndDate]     DATETIME        NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    [IsActive]    BIT             CONSTRAINT [DF_Conference_IsActive] DEFAULT ((1)) NOT NULL,
    [IsDeleted]   BIT             CONSTRAINT [DF_Conference_IsDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]   INT             NULL,
    [CreatedOn]   DATETIME        CONSTRAINT [DF_Conference_CreatedOn] DEFAULT (getdate()) NOT NULL,
    [ModifiedOn]  DATETIME        NULL,
    [ModifiedBy]  INT             NULL,
    CONSTRAINT [PK_Conference_ID] PRIMARY KEY CLUSTERED ([ID] ASC),
    CONSTRAINT [FK_Conference_CreatedBy_Users_ID] FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[Users] ([ID]),
    CONSTRAINT [FK_Conference_ModifiedBy_Users_ID] FOREIGN KEY ([ModifiedBy]) REFERENCES [dbo].[Users] ([ID])
);


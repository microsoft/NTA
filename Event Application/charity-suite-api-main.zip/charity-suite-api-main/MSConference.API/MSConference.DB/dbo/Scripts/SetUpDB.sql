﻿
create database MSConfrerence
go;

Use MSConfrerence;
go

create table Users(
	ID int identity(1,1) constraint PK_Users_ID primary key
,	LogInName nvarchar(50) not null
,	LogInPassword nvarchar(500) not null
,	FirstName nvarchar(200) not null
,	LastName nvarchar(200) null
,	Email nvarchar(200) null
,	Phone nvarchar(30) null
,	Address1 nvarchar(200) null
,	City nvarchar(200) null
,	StateName nvarchar(200) null
,	Zip nvarchar(200) null
,	CountryName nvarchar(200) null
,	IsActive bit not null constraint DF_Users_IsActive default(1)
,	IsDeleted bit not null constraint DF_Users_IsDeleted default(0)
,	CreatedOn datetime not null constraint DF_Users_CreatedOn default(getdate())
,	ModifiedOn datetime null
);
go

create table Conference(
	ID int identity(1,1) constraint PK_Conference_ID primary key
,	Name nvarchar(500) not null
,	Address nvarchar(1000) not null
,	StartDate datetime not null 
,	EndDate datetime not null 
,	Description nvarchar(2000) null
,	IsActive bit not null constraint DF_Conference_IsActive default(1)
,	IsDeleted bit not null constraint DF_Conference_IsDeleted default(0)
,	CreatedBy int constraint FK_Conference_CreatedBy_Users_ID foreign key references Users(ID)
,	CreatedOn datetime not null constraint DF_Conference_CreatedOn default(getdate())
,	ModifiedOn datetime null
,	ModifiedBy int constraint FK_Conference_ModifiedBy_Users_ID foreign key references Users(ID)
);
go

create table Sponsor(
	ID int identity(1,1) constraint PK_Sponsor_ID primary key
,	Name nvarchar(500) not null
,	Description nvarchar(2000) null
,	LogoURL nvarchar(1000) null
,	IsActive bit not null constraint DF_Sponsor_IsActive default(1)
,	IsDeleted bit not null constraint DF_Sponsor_IsDeleted default(0)
,	CreatedBy int constraint FK_Sponsor_CreatedBy_Users_ID foreign key references Users(ID)
,	CreatedOn datetime not null constraint DF_Sponsor_CreatedOn default(getdate())
,	ModifiedOn datetime null
,	ModifiedBy int constraint FK_Sponsor_ModifiedBy_Users_ID foreign key references Users(ID)
);
go


create table Session(
	ID int identity(1,1) constraint PK_Session_ID primary key
,	Name nvarchar(500) not null
,	Description nvarchar(2000) null
,	SessionDate date
,	SessionTime time
,	SpeakerName nvarchar(1000) null
,	IsActive bit not null constraint DF_Session_IsActive default(1)
,	IsDeleted bit not null constraint DF_Session_IsDeleted default(0)
,	CreatedBy int constraint FK_Session_CreatedBy_Users_ID foreign key references Users(ID)
,	CreatedOn datetime not null constraint DF_Session_CreatedOn default(getdate())
,	ModifiedOn datetime null
,	ModifiedBy int constraint FK_Session_ModifiedBy_Users_ID foreign key references Users(ID)
);
go

create table MyAgenda(	
	ConferenceID int constraint FK_MyAgenda_ConferenceID_Conference_ID foreign key references Conference(ID)
,	SessionID int constraint FK_MyAgenda_SessionID_Session_ID foreign key references Session(ID)
,	constraint PK_MyAgenda_ConferenceID_SessionID primary key(ConferenceID,SessionID)
);

go

select * from Users
select * from Conference
select * from Sponsor
select * from Session

/*
insert into Users(LogInName,LogInPassword,FirstName,LastName,Email,Phone,Address1,City,StateName,Zip,CountryName)
values('username','userpassword','Satyarth', 'Prakash', 'satyarth@omniesolutions.com','123-4506-789','Address1','City','StateName','Zip','CountryName')
*/

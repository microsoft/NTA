﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SessionGet] 
	-- Add the parameters for the stored procedure here
	@ID				int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select 
		a.ID,a.Name,isnull(a.Description,'')Description
	,	a.SessionDate,a.SessionTime
	,	isnull(a.SpeakerName,'') SpeakerName
	,	a.IsActive,a.IsDeleted,a.CreatedBy,a.CreatedOn
	,	isnull(a.ModifiedOn,a.CreatedOn) ModifiedOn,isnull(a.ModifiedBy,0) ModifiedBy
	,	isnull(c.ID,0) as ConferenceID
	,	isnull(c.Name,'') as ConferenceName
	from Session a 
	left join MyAgenda b on a.ID = b.SessionID 
	left join Conference c on c.ID = b.ConferenceID
	where a.ID = @ID
END
GO


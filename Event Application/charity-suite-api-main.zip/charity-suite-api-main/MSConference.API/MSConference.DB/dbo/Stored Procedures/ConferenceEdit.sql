﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[ConferenceEdit] 
	-- Add the parameters for the stored procedure here
	@Name			nvarchar(500)
,	@Address		nvarchar(1000)
,	@StartDate		datetime
,	@EndDate		datetime
,	@Description	nvarchar(2000)
,	@ModifiedBy		int
,	@ID				int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update Conference set 
		Name = @Name
	,	Address = @Address
	,	StartDate = @StartDate
	,	EndDate = @EndDate
	,	Description = @Description
	,	ModifiedBy = @ModifiedBy
	,	ModifiedOn = getdate()
	where ID = @ID

	select @ID as ID
END

﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SponsorGet] 
	-- Add the parameters for the stored procedure here
	@ID				int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select 
		ID,Name,isnull(Description,'') Description,isnull(LogoURL,'') LogoURL,IsActive,IsDeleted
	,	CreatedBy,CreatedOn,isnull(ModifiedOn,CreatedOn) ModifiedOn,isnull(ModifiedBy,0) ModifiedBy
	from Sponsor where ID = @ID

END

﻿-- =============================================
-- Author:		Satyarth
-- Create date: 18th Dec 2023
-- Description:	
-- =============================================

/*

UserGet 'satyarth@omniesolutions.com','userpassword'

*/

CREATE   PROCEDURE UserGet 
	-- Add the parameters for the stored procedure here
	@username varchar(200), 
	@password varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select * from Users where (LogInName = @username or Email = @username)and LogInPassword = @password
END
GO


﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================

/*

ConferenceGet 2

*/

CREATE PROCEDURE [dbo].[ConferenceGet] 
	-- Add the parameters for the stored procedure here
	@ID				int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select 
		ID,Name,Address,StartDate,EndDate,isnull(Description,'') Description,IsActive,IsDeleted
	,	CreatedBy,CreatedOn,isnull(ModifiedOn,CreatedOn) ModifiedOn,isnull(ModifiedBy,0) ModifiedBy 
	from Conference where ID = @ID

	select 
		a.ID,a.Name,isnull(a.Description,'')Description
	,	a.SessionDate,a.SessionTime
	,	isnull(a.SpeakerName,'') SpeakerName
	,	a.IsActive,a.IsDeleted,a.CreatedBy,a.CreatedOn
	,	isnull(a.ModifiedOn,a.CreatedOn) ModifiedOn,isnull(a.ModifiedBy,0) ModifiedBy	
	from MyAgenda b 
	join  Session a on a.ID = b.SessionID
	where a.IsActive = 1 and a.IsDeleted = 0
	and b.ConferenceID = @ID
	order by a.Name,a.SessionDate,a.SessionTime
END
GO


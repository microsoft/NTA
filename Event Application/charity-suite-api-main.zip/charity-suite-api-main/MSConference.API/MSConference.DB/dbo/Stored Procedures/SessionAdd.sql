﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SessionAdd] 
	-- Add the parameters for the stored procedure here
	@Name			nvarchar(500)
,	@Description	nvarchar(2000)	
,	@SessionDate	date
,	@SessionTime	time
,	@SpeakerName	nvarchar(1000)	
,	@CreatedBy		int
,	@ConferenceID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @ID int = 0

    -- Insert statements for procedure here
	insert into Session
		(Name,Description,SessionDate,SessionTime,SpeakerName,CreatedBy)
	values
		(@Name,@Description,@SessionDate,@SessionTime,@SpeakerName,@CreatedBy)

	select @ID = IDENT_CURRENT('Session')

	insert into MyAgenda(ConferenceID,SessionID)
	select @ConferenceID,@ID

	select @ID as ID
END
GO


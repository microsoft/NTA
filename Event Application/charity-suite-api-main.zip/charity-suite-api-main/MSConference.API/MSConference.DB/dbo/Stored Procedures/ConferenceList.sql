﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE ConferenceList 
	-- Add the parameters for the stored procedure here	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select 
		ID,Name,Address,StartDate,EndDate,isnull(Description,'') Description,IsActive,IsDeleted
	,	CreatedBy,CreatedOn,isnull(ModifiedOn,CreatedOn) ModifiedOn,isnull(ModifiedBy,0) ModifiedBy 
	from Conference where IsActive = 1 and IsDeleted = 0
	order by StartDate,Name
END

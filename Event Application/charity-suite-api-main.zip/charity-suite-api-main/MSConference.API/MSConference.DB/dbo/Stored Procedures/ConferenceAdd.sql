﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[ConferenceAdd] 
	-- Add the parameters for the stored procedure here
	@Name			nvarchar(500)
,	@Address		nvarchar(1000)
,	@StartDate		datetime
,	@EndDate		datetime
,	@Description	nvarchar(2000)
,	@CreatedBy		int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @ID int = 0

    -- Insert statements for procedure here
	insert into Conference
		(Name,Address,StartDate,EndDate,Description,CreatedBy)
	values
		(@Name,@Address,@StartDate,@EndDate,@Description,@CreatedBy)

	select @ID = IDENT_CURRENT('Conference')

	select @ID as ID
END

﻿-- =============================================
-- Author:		Satyarth Prakash Gupta
-- Create date: 7th Dec 2023
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SponsorAdd] 
	-- Add the parameters for the stored procedure here
	@Name			nvarchar(500)
,	@Description	nvarchar(2000)
,	@LogoURL		nvarchar(1000)
,	@CreatedBy		int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @ID int = 0

    -- Insert statements for procedure here
	insert into Sponsor
		(Name,Description,LogoURL,CreatedBy)
	values
		(@Name,@Description,@LogoURL,@CreatedBy)

	select @ID = IDENT_CURRENT('Sponsor')

	select @ID as ID
END

using MSConference.API.Middleware;
using MSConference.Entity;
using MSConference.Manager;

namespace MSConference.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();


            var provider = builder.Services.BuildServiceProvider();
            var configuration = provider.GetService<IConfiguration>();
            builder.Services.Configure<AppSettings>(configuration.GetSection("AppSettings"));


            builder.Services.AddTransient<IManager<Conference>, Manager<Conference>>();

            //var conferenMgr = new Manager<Conference>();
            //conferenMgr.Add(new Conference());

            //var sessMgr = new Manager<Session>();

            //sessMgr.Add(new Session());


            builder.Services.AddTransient<IConferenceManager, ConferenceManager>();
            builder.Services.AddTransient<ISponsorManager, SponsorManager>();
            builder.Services.AddTransient<ISessionManager, SessionManager>();
            builder.Services.AddScoped<IUserManager, UserManager>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment() || app.Environment.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseMiddleware<BasicAuthMiddleware>();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
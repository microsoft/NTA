﻿using MSConference.Entity;
using MSConference.Manager;

namespace MSConference.API
{
    public class StartUp
    {
        public StartUp(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            // Add services to the container.

            services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();

            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));

            services.AddTransient<IManager<Conference>, Manager<Conference>>();

            //var conferenMgr = new Manager<Conference>();
            //conferenMgr.Add(new Conference());

            //var sessMgr = new Manager<Session>();

            //sessMgr.Add(new Session());


            services.AddTransient<IConferenceManager, ConferenceManager>();
            services.AddTransient<ISponsorManager, SponsorManager>();
            services.AddTransient<ISessionManager, SessionManager>();
        }

        public void Configure(WebApplication app, IWebHostEnvironment env)
        {
            // Configure the HTTP request pipeline.
            if (env.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseAuthorization();

            app.MapControllers();
            app.Run();
        }
    }
}

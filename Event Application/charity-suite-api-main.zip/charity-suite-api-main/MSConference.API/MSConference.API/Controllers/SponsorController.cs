﻿using Microsoft.AspNetCore.Mvc;
using MSConference.Entity;
using MSConference.Manager;
using System.Text.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MSConference.API.Controllers
{
    [Attributes.Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SponsorController : ControllerBase
    {
        private readonly ISponsorManager _iSponsorManager;
        private readonly ILogger<SponsorController> _logger;

        public SponsorController(ISponsorManager iSponsorManager, ILogger<SponsorController> logger)
        {
            _iSponsorManager = iSponsorManager;
            _logger = logger;
        }

        // GET: api/<SponsorController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var _sponsor = _iSponsorManager.Get();

                _logger.LogInformation($"Sponsor Count - {_sponsor.Count}");

                return Ok(_sponsor);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Get Sponsor");
                return NotFound();
            }
        }

        // GET api/<SponsorController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                return Ok(_iSponsorManager.Get(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Get Sponsor By ID");
                return NotFound();
            }
        }

        // POST api/<SponsorController>
        [HttpPost]
        public IActionResult Post([FromBody] Sponsor value)
        {
            _logger.LogInformation($"Sponsor Add Payload - {JsonSerializer.Serialize(value)}");

            try
            {
                return Ok(_iSponsorManager.Add(value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Post/Add Sponsor");
                return NotFound();
            }
        }

        // PUT api/<SponsorController>/5
        [HttpPut()]
        public IActionResult Put(int id, [FromBody] Sponsor value)
        {
            _logger.LogInformation($"Sponsor Update Payload - {JsonSerializer.Serialize(value)}");

            try
            {
                return Ok(_iSponsorManager.Edit(value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Put/Update Sponsor");
                return NotFound();
            }
        }

        // DELETE api/<SponsorController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _logger.LogInformation($"Sponsor Delete for - {id}");

            try
            {
                return Ok(_iSponsorManager.Delete(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Delete Sponsor");
                return NotFound();
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using MSConference.Entity;
using MSConference.Manager;
using System.Text.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MSConference.API.Controllers
{
    [Attributes.Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SessionController : ControllerBase
    {
        private readonly ISessionManager _iSessionManager;
        private readonly ILogger<SessionController> _logger;

        public SessionController(ISessionManager iSessionManager, ILogger<SessionController> logger)
        {
            _iSessionManager = iSessionManager;
            _logger = logger;
        }

        // GET: api/<SessionController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var _session = _iSessionManager.Get();

                _logger.LogInformation($"Session Count - {_session.Count}");

                return Ok(_session);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Get Session");
                return NotFound();
            }
        }

        // GET api/<SessionController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                return Ok(_iSessionManager.Get(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Get Session By ID");
                return NotFound();
            }
        }

        // POST api/<SessionController>
        [HttpPost]
        public IActionResult Post([FromBody] Session value)
        {
            _logger.LogInformation($"Session Add Payload - {JsonSerializer.Serialize(value)}");

            try
            {
                return Ok(_iSessionManager.Add(value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Post/Add Session");
                return NotFound();
            }
        }

        // PUT api/<SessionController>/5
        [HttpPut()]
        public IActionResult Put([FromBody] Session value)
        {
            _logger.LogInformation($"Session Update Payload - {JsonSerializer.Serialize(value)}");

            try
            {
                return Ok(_iSessionManager.Edit(value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Put/Update Session");
                return NotFound();
            }
        }

        // DELETE api/<SessionController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _logger.LogInformation($"Session Delete for - {id}");

            try
            {
                return Ok(_iSessionManager.Delete(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Delete Session");
                return NotFound();
            }
        }
    }
}

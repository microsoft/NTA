﻿using Microsoft.AspNetCore.Mvc;
using MSConference.Entity;
using MSConference.Manager;
using System.Text.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MSConference.API.Controllers
{
    [Attributes.Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ConferenceController : ControllerBase
    {
        private readonly IConferenceManager _iConferenceManager;
        private readonly ILogger<ConferenceController> _logger;

        public ConferenceController(IConferenceManager iConferenceManager, ILogger<ConferenceController> logger)
        {
            _iConferenceManager = iConferenceManager;
            _logger = logger;
        }

        // GET: api/<ConferenceController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var _conference = _iConferenceManager.Get();

                _logger.LogInformation($"Conference Count - {_conference.Count}");

                return Ok(_conference);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Get Conference");
                return NotFound();
            }
        }

        // GET api/<ConferenceController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                return Ok(_iConferenceManager.Get(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Get Conference By ID");
                return NotFound();
            }
        }

        // POST api/<ConferenceController>
        [HttpPost]
        public IActionResult Post([FromBody] Conference value)
        {
            _logger.LogInformation($"Conference Add Payload - {JsonSerializer.Serialize(value)}");

            try
            {
                return Ok(_iConferenceManager.Add(value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Post/Add Conference");
                return NotFound();
            }
        }

        // PUT api/<ConferenceController>/5
        [HttpPut]
        public IActionResult Put([FromBody] Conference value)
        {
            _logger.LogInformation($"Conference Upadte Payload - {JsonSerializer.Serialize(value)}");

            try
            {
                return Ok(_iConferenceManager.Edit(value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Put/Update Conference");
                return NotFound();
            }
        }

        // DELETE api/<ConferenceController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _logger.LogInformation($"Conference Delete for - {id}");

            try
            {
                return Ok(_iConferenceManager.Delete(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Delete Conference");
                return NotFound();
            }
        }
    }
}

﻿global using CommunityToolkit.Mvvm.ComponentModel;
global using ObservableObject = CommunityToolkit.Mvvm.ComponentModel.ObservableObject;

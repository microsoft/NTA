﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using CommunityToolkit.Mvvm.Input;
using Jeffsum;
using MvvmHelpers;
using MyConference.Models;
using MyConference.WebServices;
using static Jeffsum.Goldblum;

namespace MyConference.ViewModels;


public partial class ConferenceViewModel : BaseViewModel
{    
    public int Day { get; set; }
    public ObservableRangeCollection<Grouping<string, Conference>> _Schedule = new();
    Random random = new ();
    WebService _restService;
    Boolean isEnableOrNot = false;
    public ObservableCollection<Conference> conferenceList = new ObservableCollection<Conference>();


    public ObservableRangeCollection<Grouping<string, Conference>> Schedule
    {
        get { return _Schedule; }
        set
        {
            _Schedule = value;
            OnPropertyChanged(nameof(Schedule));
        }
    }

    [Obsolete]
    public ConferenceViewModel()
    {
        _restService = new WebService();
        isEnableOrNot = (Device.RuntimePlatform == Device.iOS) ? true : false;
    }
    public async void serviceCall()
    {

        conferenceList = await _restService.GetConferenceAsync(ApiConstants.getConference);
        var sorted = from session in conferenceList
                     orderby session.StartDate
                     group session by session.StartDateDisplay into sessionGroup
                     select new Grouping<string, Conference>(sessionGroup.Key, sessionGroup);
       
        Schedule.Clear();

        Schedule.AddRange(sorted.Reverse());

    }
    




}

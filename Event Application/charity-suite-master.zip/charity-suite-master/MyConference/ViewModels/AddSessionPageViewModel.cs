﻿using System.Collections.ObjectModel;
using MyConference.Models;
using MyConference.WebServices;

namespace MyConference.ViewModels
{
	public class AddSessionPageViewModel: BaseViewModel
    {
        WebService _restService;
        private Conference _SelectedConference;
        public Conference SelectedConference
        {
            get { return _SelectedConference; }
            set
            {
                _SelectedConference = value;
                OnPropertyChanged(nameof(SelectedConference));
            }
        }
        private ObservableCollection<Conference> _conferenceList;
        public ObservableCollection<Conference> conferenceList
        {
            get { return _conferenceList; }
            set
            {
                _conferenceList = value;
                OnPropertyChanged(nameof(conferenceList));
            }
        }

        public AddSessionPageViewModel()
		{

            conferenceList = new ObservableCollection<Conference>();
            _restService = new WebService();
            serviceCall();

        }
        public async void serviceCall()
        {
            conferenceList = await _restService.GetConferenceAsync(ApiConstants.getConference);
        }

    }
}


﻿
using System.Diagnostics;
using MvvmHelpers;
using MyConference.Models;
using MyConference.WebServices;

namespace MyConference.ViewModels
{
	public class ConferenceDetailViewModel: BaseViewModel
    {
        public ObservableRangeCollection<Grouping<string, ConfSession>> _Schedule = new();
        public ObservableRangeCollection<Grouping<string, ConfSession>> Schedule
        {
            get { return _Schedule; }
            set
            {
                _Schedule = value;
                OnPropertyChanged(nameof(Schedule));
            }
        }
        private Conference _aConference;
        public Conference aConference
        {
            get { return _aConference; }
            set
            {
                _aConference = value;
                OnPropertyChanged(nameof(aConference));
            }
        }
        WebService _restService;
        public ConferenceDetailViewModel()
		{
            aConference = new Conference();
            _restService = new WebService();
           

        }
        

       
        public async void serviceCall(String confID)
        {
            String url = ApiConstants.getConference + "/" + confID;
            aConference = await _restService.GetConferenceDetailAsync(url);
            Schedule.Clear();
            var sorted = from session in aConference.Sessions
                         orderby session.SessionTime
                         group session by session.DateDisplay + ", " +session.StartTimeDisplay into sessionGroup
                         select new Grouping<string, ConfSession>(sessionGroup.Key, sessionGroup);
            Schedule.AddRange(sorted);
        }

    }
}


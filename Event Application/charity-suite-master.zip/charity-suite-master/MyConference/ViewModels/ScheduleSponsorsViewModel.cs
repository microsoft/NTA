﻿using System.Collections.ObjectModel;

using MyConference.Models;
using MyConference.WebServices;
using static Jeffsum.Goldblum;

namespace MyConference.ViewModels;


public partial class ScheduleSponsorsViewModel : BaseViewModel
{    
    public int Day { get; set; }
    Random random = new ();
    WebService _restService;

    private ObservableCollection<Sponsor> _sponsorList;
    public ObservableCollection<Sponsor> sponsorList
    {
        get { return _sponsorList; }
        set
        {
            _sponsorList = value;
            OnPropertyChanged(nameof(sponsorList));
        }
    }
    

    public ScheduleSponsorsViewModel()
    {
        _restService = new WebService();
    }
    public async void serviceCall()
    {
      
        sponsorList = await _restService.GetSponsorsAsync(ApiConstants.getSponsor);
       
    }
 
}

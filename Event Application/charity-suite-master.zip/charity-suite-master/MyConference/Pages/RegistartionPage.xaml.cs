﻿namespace MyConference.Pages;

public partial class RegistartionPage : ContentPage
{
	public RegistartionPage()
	{
		InitializeComponent();
	}

    void Signup_Clicked(System.Object sender, System.EventArgs e)
    {
    }
}

using Microsoft.Maui.Controls;
using MyConference.Models;
using MyConference.ViewModels;

namespace MyConference.Pages;

public partial class ScheduleDayCong1Page : SchedulePageConference
{
	public ScheduleDayCong1Page(ConferenceViewModel vmm) : base()
	{
        vmm.Day = 1;
        Title = "Conferences";
        BindingContext = vmm;
	}
}


public partial class SchedulePageConference : ContentPage
{
    ConferenceViewModel vm;
    ConferenceViewModel VM => vm ??= BindingContext as ConferenceViewModel;
    public SchedulePageConference()
    {
        InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        VM.serviceCall();
    }
    protected  void OnItemSelected(Object sender, ItemTappedEventArgs e)
    {
        var aConf = e.Item as Conference;
          Navigation.PushAsync(new ConferenceDetailPage(aConf));
     
    }
    protected override void OnNavigatedTo(NavigatedToEventArgs args)
	{
		base.OnNavigatedTo(args);
	}

}
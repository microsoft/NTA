using MyConference.ViewModels;

namespace MyConference.Pages;

public partial class AgendaPage : ContentPage
{
	public AgendaPage()
	{
		InitializeComponent();
	}
}
﻿
using MyConference.Models;
using MyConference.ViewModels;
using MyConference.WebServices;

namespace MyConference.Pages;

public partial class AddSessionPage : ContentPage
{
    AddSessionPageViewModel vm;
    AddSessionPageViewModel VM => vm ??= BindingContext as AddSessionPageViewModel;
    WebService _restService;

    public AddSessionPage()
	{
		InitializeComponent();
        _restService = new WebService();
     

    }
   
    protected override void OnAppearing()
    {
        base.OnAppearing();
    }
    async void Add_Clicked(System.Object sender, System.EventArgs e)
    {
       
        if (ConferencePicker.SelectedItem == null)
            {
            await DisplayAlert("Select", "Please select a conference ", "OK");

            
        }
        else if (nameField.Text == null)
        {
            await DisplayAlert("Select", "Please enater name ", "OK");


        }
        else if (descriptionField.Text == null)
        {
            await DisplayAlert("Select", "Please enter descrption ", "OK");


        }
        else if (speakerField.Text == null)
        {
            await DisplayAlert("Select", "Please enter speaker name ", "OK");


        }
        else if (VM.SelectedConference.EndDate < datePicker1.Date)
            await DisplayAlert("Select", "Date should not be grater than the conference end date - " + VM.SelectedConference.EndDateD, "OK");
        else
        {
           
             callWeb();
        }

    }
    async void callWeb()
    {


        RequestSession post = new RequestSession();

        post.name = nameField.Text;
        post.description = descriptionField.Text;
        post.sessionDate = datePicker1.Date.ToString("yyyy-MM-dd");
        post.sessionTime = timePicker.Time.ToString();
        post.speakerName = speakerField.Text;

        post.conferenceID = VM.SelectedConference.Id.ToString();
        Boolean status = await _restService.AddSessionAsync(ApiConstants.addSession, post);
        if (status)
        {
            await DisplayAlert("Session", "Added successfully", "OK");
            navigateToBack();
        }
        else
        {
            await DisplayAlert("Session", "Something went wrong", "OK");
        }
    }
   
    void navigateToBack()
    {
        Navigation.PopAsync();
    }
}


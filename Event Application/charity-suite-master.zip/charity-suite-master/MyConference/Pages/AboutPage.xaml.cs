﻿
using MyConference.ViewModels;
using MyConference.WebServices;

namespace MyConference.Pages;

public partial class AboutPage : ContentPage
{
    public AboutPage()
    {
        InitializeComponent();
        NavigationPage.SetBackButtonTitle(this, "ok");
        
    }
    protected override void OnAppearing()
    {

        updateUI();
       
        base.OnAppearing();
    }
    void updateUI()
    {
        var myValue = Preferences.Get("userid", "default_value");

        loginButton.Text = (myValue != "default_value") ? "User Detail" : "Login";
        addConference.IsVisible = myValue != "default_value";
        addSession.IsVisible = myValue != "default_value";
        addSponsor.IsVisible = myValue != "default_value";
        logoimage.IsVisible = myValue == "default_value";
        seperateline1.IsVisible = myValue == "default_value";
        seperateline2.IsVisible = myValue == "default_value";
        versionapp.IsVisible = myValue == "default_value";
        versionapp.Text = AppConstants.iosVersion;
    }
    void LoginButton_Clicked(System.Object sender, System.EventArgs e)
    {
        Navigation.PushAsync(new LoginPage());
    }

    void AddConference_Clicked(System.Object sender, System.EventArgs e)
    {
        Navigation.PushAsync(new AddConferencePage());
    }
    void AddSession_Clicked(System.Object sender, System.EventArgs e)
    {
        Navigation.PushAsync(new AddSessionPage());
    }
    void AddSponsor_Clicked(System.Object sender, System.EventArgs e)
    {
        Navigation.PushAsync(new AddSponsors());
    }
    void Logout_Clicked(System.Object sender, System.EventArgs e)
    {
        Preferences.Set("userid", null);
        Preferences.Set("password", null);
        updateUI();
    }
}
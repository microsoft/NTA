﻿using MyConference.Models;
using MyConference.ViewModels;

namespace MyConference.Pages;

public partial class ConferenceDetailPage : ContentPage
{
    Conference aConference;
    ConferenceDetailViewModel vm;
    ConferenceDetailViewModel VM => vm ??= BindingContext as ConferenceDetailViewModel;
    public ConferenceDetailPage(Conference aConf)
	{
		InitializeComponent();
        aConference = aConf;
        nameLbl.Text = aConf.Name;

    }
    protected override void OnAppearing()
    {

        base.OnAppearing();
       
        VM.serviceCall(aConference.Id.ToString());

      
    }
    }

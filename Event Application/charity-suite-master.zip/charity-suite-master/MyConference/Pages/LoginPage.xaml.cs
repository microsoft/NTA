﻿using System.Diagnostics;
using MyConference.WebServices;

namespace MyConference.Pages;

public partial class LoginPage : ContentPage
{
	public LoginPage()
	{
		InitializeComponent();
        var myValue = Preferences.Get("userid", "default_value");
        if (myValue == AppConstants.LoginUsername)
        {
            signButton.IsVisible = false;
            logoutButton.IsVisible = true;
            emailEntry.Text = AppConstants.LoginUsername;
             passEntry.Text = AppConstants.LoginPassword;
            emailEntry.IsReadOnly = true;
            passEntry.IsReadOnly = true;
        }

        else
        {
            signButton.IsVisible = true;
            logoutButton.IsVisible = false;
            emailEntry.IsReadOnly = false;
            passEntry.IsReadOnly = false;
        }
       
    }

    void LoginClicked(System.Object sender, System.EventArgs e)
    {
        
        if (emailEntry.Text == null)
        {
            DisplayAlert("Select", "Please enter username", "OK");
        }
        else if (passEntry.Text == null)
        {
            DisplayAlert("Select", "Please enter password", "OK");
        }
        else
        {
            if (emailEntry.Text.ToLower() == AppConstants.LoginUsername && passEntry.Text.ToLower() == AppConstants.LoginPassword)
            {
                Preferences.Set("userid", emailEntry.Text.ToLower());
                Preferences.Set("password", passEntry.Text);
                Navigation.PopAsync();
            }
            else
            {
                DisplayAlert("Select", "Username or password incorrect.", "OK");
            }

        }

    }
    void LogoutClicked(System.Object sender, System.EventArgs e)
    {
        Preferences.Set("userid", null);
        Preferences.Set("password", null);
        Navigation.PopAsync();
    }
}

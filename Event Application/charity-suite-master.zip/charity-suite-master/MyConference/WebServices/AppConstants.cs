﻿using System;
namespace MyConference.WebServices
{
	public class AppConstants
	{
        public const string iosVersion = "1.0.7";
        public const string LoginUsername = "username";
        public const string LoginPassword = "userpassword";

        public AppConstants()
		{
		}
	}
}

